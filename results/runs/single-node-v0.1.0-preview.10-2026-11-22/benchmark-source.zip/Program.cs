using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Squirix;
using Squirix.Client;

const int sessionCount = 48;
var keys = new string[16_384];
for (var i = 0; i < keys.Length; i++)
    keys[i] = $"key:{i:D12}";

var value = new string('x', 254);
if (args is ["certificates", var directory])
{
    Certificates.Create(directory);
    return;
}

var system = args[0];
var repetition = int.Parse(args[1], CultureInfo.InvariantCulture);
var measurementSeconds = int.Parse(args[2], CultureInfo.InvariantCulture);
var rates = args[3].Split(',').Select(static value => int.Parse(value, CultureInfo.InvariantCulture)).ToArray();
var usesSquirix = system == "Squirix";
var commands = new RespCommands(keys, value);
var endpoint = new Uri("https://localhost:6380");
var sessions = new List<ISession>();

using var startup = new CancellationTokenSource(TimeSpan.FromMinutes(2));
try
{
    var probe = await (usesSquirix
        ? SquirixSession.ConnectAsync(endpoint, keys, startup.Token)
        : RespSession.ConnectAsync(endpoint, commands, startup.Token));
    sessions.Add(probe);
    await probe.ExecuteAsync(0, true, startup.Token);
    await probe.ExecuteAsync(0, false, startup.Token);
    Console.Error.WriteLine($"{system}: TLS SET/GET passed");

    var opening = Enumerable.Range(1, sessionCount - 1).Select(_ => usesSquirix
        ? SquirixSession.ConnectAsync(endpoint, keys, startup.Token)
        : RespSession.ConnectAsync(endpoint, commands, startup.Token));
    sessions.AddRange(await Task.WhenAll(opening));
    await Task.WhenAll(sessions.Select(async (session, worker) =>
    {
        for (var key = worker; key < keys.Length; key += sessions.Count)
            await session.ExecuteAsync(key, true, startup.Token);
    }));
    Console.Error.WriteLine($"{system}: seeded {keys.Length} keys on {sessionCount} sessions");

    var seed = 1138 + repetition;
    _ = await MeasureAsync(sessions, rates[0], 5, seed, keys.Length);
    foreach (var rate in rates)
    {
        _ = await MeasureAsync(sessions, rate, 2, seed, keys.Length);
        var result = await MeasureAsync(sessions, rate, measurementSeconds, seed, keys.Length);
        Console.WriteLine(JsonSerializer.Serialize(new { System = system, Repetition = repetition, Result = result }));
        Console.Error.WriteLine($"{system}: {rate}/s, p99 GET {result.Read.P99Ms:F3} ms, drops {result.Dropped}");
    }
}
finally
{
    foreach (var session in sessions)
        await session.DisposeAsync();
}

static async Task<PointResult> MeasureAsync(
    IReadOnlyList<ISession> sessions, int rate, int seconds, int seed, int keyCount)
{
    var total = checked(rate * seconds);
    var random = new Random(seed);
    var keyIds = new int[total];
    for (var i = 0; i < total; i++)
        keyIds[i] = random.Next(keyCount);

    var queue = Channel.CreateBounded<Work>(new BoundedChannelOptions(sessions.Count * 8)
    {
        SingleWriter = true,
        FullMode = BoundedChannelFullMode.Wait,
    });
    var latency = new long[total];
    var serviceTime = new long[total];
    var schedulerLag = new long[total];
    var completedInWindow = new bool[total];
    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(seconds + 20));
    var start = Stopwatch.GetTimestamp() + Stopwatch.Frequency / 10;
    var end = start + seconds * Stopwatch.Frequency;

    var workers = sessions.Select(async session =>
    {
        await foreach (var work in queue.Reader.ReadAllAsync(timeout.Token))
        {
            var dispatched = Stopwatch.GetTimestamp();
            await session.ExecuteAsync(keyIds[work.Index], work.Index % 20 == 0, timeout.Token);
            var completed = Stopwatch.GetTimestamp();
            latency[work.Index] = completed - work.Due;
            serviceTime[work.Index] = completed - dispatched;
            completedInWindow[work.Index] = completed <= end;
        }
    }).ToArray();

    var dropped = 0;
    var scheduler = new Thread(() =>
    {
        for (var index = 0; index < total; index++)
        {
            var due = start + index * Stopwatch.Frequency / rate;
            long now;
            while ((now = Stopwatch.GetTimestamp()) < due)
                Thread.SpinWait(12);
            schedulerLag[index] = now - due;
            if (!queue.Writer.TryWrite(new Work(index, due)))
                dropped++;
        }
        _ = queue.Writer.TryComplete();
    });
    scheduler.IsBackground = true;
    scheduler.Start();
    await Task.WhenAll(workers);
    scheduler.Join();

    var reads = new List<long>(total);
    var writes = new List<long>(total / 20);
    var readService = new List<long>(total);
    for (var i = 0; i < total; i++)
    {
        if (latency[i] == 0)
            continue;
        if (i % 20 == 0)
            writes.Add(latency[i]);
        else
        {
            reads.Add(latency[i]);
            readService.Add(serviceTime[i]);
        }
    }

    return new PointResult(rate, seconds, total, dropped, completedInWindow.Count(static done => done),
        Distribution.From(reads), Distribution.From(writes), Distribution.From(readService),
        Distribution.From(new List<long>(schedulerLag)));
}

internal readonly record struct Work(int Index, long Due);

internal sealed record PointResult(int OfferedOpsPerSecond, int Seconds, int Offered, int Dropped,
    int CompletedWithinWindow, Distribution Read, Distribution Write, Distribution ReadService, Distribution SchedulerLag);

internal readonly record struct Distribution(int Count, double P50Ms, double P95Ms, double P99Ms)
{
    public static Distribution From(List<long> samples)
    {
        samples.Sort();
        return new(samples.Count, At(samples, .5), At(samples, .95), At(samples, .99));
    }

    private static double At(List<long> samples, double percentile) => samples.Count == 0
        ? 0
        : samples[(int)Math.Ceiling(samples.Count * percentile) - 1] * 1000.0 / Stopwatch.Frequency;
}

internal interface ISession : IAsyncDisposable
{
    ValueTask ExecuteAsync(int key, bool write, CancellationToken cancellationToken);
}

internal sealed class SquirixSession : ISession
{
    private static readonly string Value = new('x', 254);
    private readonly ISquirixClient _client;
    private readonly ICache<string> _cache;
    private readonly string[] _keys;

    private SquirixSession(ISquirixClient client, ICache<string> cache, string[] keys)
    {
        _client = client;
        _cache = cache;
        _keys = keys;
    }

    public static async Task<ISession> ConnectAsync(Uri endpoint, string[] keys, CancellationToken cancellationToken)
    {
        var client = await SquirixClient.ConnectAsync(endpoint, cancellationToken);
        try
        {
            var cache = await client.GetCacheAsync<string>("local-benchmark", cancellationToken);
            return new SquirixSession(client, cache, keys);
        }
        catch
        {
            await client.DisposeAsync();
            throw;
        }
    }

    public async ValueTask ExecuteAsync(int key, bool write, CancellationToken cancellationToken)
    {
        var name = _keys[key];
        if (write)
        {
            await _cache.SetAsync(name, Value, cancellationToken: cancellationToken);
            return;
        }

        var result = await _cache.GetValueAsync(name, cancellationToken);
        if (!result.Found || !string.Equals(result.Value, Value, StringComparison.Ordinal))
            throw new InvalidDataException("Unexpected value from Squirix.");
    }

    public ValueTask DisposeAsync() => _client.DisposeAsync();
}

internal sealed class RespCommands
{
    public byte[][] Gets { get; }
    public byte[][] Sets { get; }
    public byte[] ExpectedValue { get; }

    public RespCommands(string[] keys, string value)
    {
        var json = JsonSerializer.Serialize(value);
        ExpectedValue = Encoding.ASCII.GetBytes($"${json.Length}\r\n{json}\r\n");
        Gets = keys.Select(static key => Encoding.ASCII.GetBytes($"*2\r\n$3\r\nGET\r\n$16\r\n{key}\r\n")).ToArray();
        Sets = keys.Select(key => Encoding.ASCII.GetBytes($"*3\r\n$3\r\nSET\r\n$16\r\n{key}\r\n${json.Length}\r\n{json}\r\n")).ToArray();
    }
}

internal sealed class RespSession : ISession
{
    private readonly TcpClient _client;
    private readonly SslStream _stream;
    private readonly RespCommands _commands;
    private readonly byte[] _response;

    private RespSession(TcpClient client, SslStream stream, RespCommands commands)
    {
        _client = client;
        _stream = stream;
        _commands = commands;
        _response = new byte[commands.ExpectedValue.Length];
    }

    public static async Task<ISession> ConnectAsync(Uri endpoint, RespCommands commands, CancellationToken cancellationToken)
    {
        var client = new TcpClient { NoDelay = true };
        try
        {
            await client.ConnectAsync(endpoint.Host, endpoint.Port, cancellationToken);
            var stream = new SslStream(client.GetStream());
            try
            {
                await stream.AuthenticateAsClientAsync(new SslClientAuthenticationOptions { TargetHost = endpoint.Host }, cancellationToken);
                return new RespSession(client, stream, commands);
            }
            catch
            {
                await stream.DisposeAsync();
                throw;
            }
        }
        catch
        {
            client.Dispose();
            throw;
        }
    }

    public async ValueTask ExecuteAsync(int key, bool write, CancellationToken cancellationToken)
    {
        var request = write ? _commands.Sets[key] : _commands.Gets[key];
        await _stream.WriteAsync(request, cancellationToken);
        var length = write ? 5 : _commands.ExpectedValue.Length;
        await _stream.ReadExactlyAsync(_response.AsMemory(0, length), cancellationToken);
        var expected = write ? "+OK\r\n"u8 : _commands.ExpectedValue.AsSpan();
        if (!_response.AsSpan(0, length).SequenceEqual(expected))
            throw new InvalidDataException("Unexpected RESP reply.");
    }

    public async ValueTask DisposeAsync()
    {
        await _stream.DisposeAsync();
        _client.Dispose();
    }
}

internal static class Certificates
{
    public static void Create(string directory)
    {
        _ = Directory.CreateDirectory(directory);
        using var rootKey = RSA.Create(2048);
        var rootRequest = new CertificateRequest("CN=Squirix local benchmark root", rootKey, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        rootRequest.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, false, 0, true));
        rootRequest.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign | X509KeyUsageFlags.CrlSign, true));
        rootRequest.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(rootRequest.PublicKey, false));
        var now = DateTimeOffset.UtcNow.AddMinutes(-10);
        using var root = rootRequest.CreateSelfSigned(now, now.AddDays(2));
        using var key = RSA.Create(2048);
        var request = new CertificateRequest("CN=localhost", key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        var names = new SubjectAlternativeNameBuilder();
        names.AddDnsName("localhost");
        names.AddIpAddress(IPAddress.Loopback);
        request.CertificateExtensions.Add(names.Build());
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection { new("1.3.6.1.5.5.7.3.1") }, false));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature | X509KeyUsageFlags.KeyEncipherment, true));
        using var publicCert = request.Create(root, now, now.AddDays(1), RandomNumberGenerator.GetBytes(16));
        using var cert = publicCert.CopyWithPrivateKey(key);
        File.WriteAllText(Path.Combine(directory, "ca.crt"), root.ExportCertificatePem());
        File.WriteAllText(Path.Combine(directory, "server.crt"), cert.ExportCertificatePem());
        File.WriteAllText(Path.Combine(directory, "server.key"), key.ExportPkcs8PrivateKeyPem());
        File.WriteAllBytes(Path.Combine(directory, "server.pfx"), cert.Export(X509ContentType.Pkcs12, "benchmark-cert"));
    }
}
