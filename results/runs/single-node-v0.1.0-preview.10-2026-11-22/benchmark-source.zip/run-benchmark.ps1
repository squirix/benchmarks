param(
    [switch] $Pilot,
    [int[]] $Repetitions = @(1, 2, 3),
    [ValidateSet('Squirix', 'Garnet', 'Valkey', 'Redis')]
    [string[]] $Only = @('Squirix', 'Garnet', 'Valkey', 'Redis')
)

$ErrorActionPreference = 'Stop'
$useRtk = [bool](Get-Command rtk -ErrorAction SilentlyContinue)

function Invoke-BenchDocker {
    if ($useRtk) { rtk proxy docker @args }
    else { docker @args }
}

$aspnetImage = 'mcr.microsoft.com/dotnet/aspnet:10.0'
$sourceRoot = $PSScriptRoot.Replace('\', '/')
$certMount = "type=bind,source=$sourceRoot/certs,target=/certs,readonly"
$loadMount = "type=bind,source=$sourceRoot/bin/Release/net10.0,target=/load,readonly"
$runId = [Guid]::NewGuid().ToString('N').Substring(0, 8)
$seconds = 6
$rates = '2000,5000,8000,20000'
$outputRoot = Join-Path $PSScriptRoot 'measurements'
if ($Pilot) {
    $Repetitions = @(0)
    $seconds = 2
    $rates = '2000,20000'
    $outputRoot = Join-Path $PSScriptRoot 'pilot'
}
[void][IO.Directory]::CreateDirectory($outputRoot)
$utf8 = [Text.UTF8Encoding]::new($false)
$images = @{
    Squirix = $aspnetImage
    Garnet = 'ghcr.io/microsoft/garnet:2.2.13'
    Valkey = 'valkey/valkey:9.2.0'
    Redis = 'redis:8.10.3'
}
$orders = @(
    @('Squirix', 'Garnet', 'Valkey', 'Redis'),
    @('Garnet', 'Redis', 'Squirix', 'Valkey'),
    @('Redis', 'Valkey', 'Garnet', 'Squirix')
)

foreach ($repetition in $Repetitions) {
    $order = $orders[[Math]::Max(0, $repetition - 1)]
    foreach ($system in $order) {
        if ($system -notin $Only) { continue }
        $output = Join-Path $outputRoot "$system-$repetition.jsonl"
        if (Test-Path -LiteralPath $output) {
            throw "Measurement file already exists: $output"
        }

        $containerName = "squirix-bench-$runId-$($system.ToLowerInvariant())-$repetition"
        $server = @('run', '--detach', '--rm', '--name', $containerName, '--cpuset-cpus', '12-15',
            '--memory', '4g', '--mount', $certMount)
        switch ($system) {
            'Squirix' {
                $server += @('--mount', "type=bind,source=$sourceRoot/server-package/tools/net10.0/any,target=/server,readonly",
                    '--env', 'ASPNETCORE_Kestrel__Certificates__Default__Path=/certs/server.pfx',
                    '--env', 'ASPNETCORE_Kestrel__Certificates__Default__Password=benchmark-cert',
                    '--env', 'Logging__LogLevel__Default=Warning',
                    $aspnetImage, 'dotnet', '/server/Squirix.Server.Host.dll',
                    'run', '--urls', 'https://127.0.0.1:6380')
            }
            'Garnet' {
                $server += @('--mount', "type=bind,source=$sourceRoot/garnet.conf,target=/bench.conf,readonly",
                    $images[$system], '--config-import-path', '/bench.conf', '--bind', '127.0.0.1', '--port', '6380', '--tls',
                    '--cert-file-name', '/certs/server.pfx', '--cert-password', 'benchmark-cert',
                    '--memory', '512m', '--index', '16m', '--no-obj')
            }
            { $_ -in @('Redis', 'Valkey') } {
                $binary = $system.ToLowerInvariant() + '-server'
                $server += @('--mount', "type=bind,source=$sourceRoot/redis-family.conf,target=/bench.conf,readonly",
                    $images[$system], $binary, '/bench.conf')
            }
        }

        Write-Host "Starting $system repetition $repetition"
        Invoke-BenchDocker @server
        if ($LASTEXITCODE -ne 0) { throw "Could not start $system" }

        try {
            Start-Sleep -Seconds 2
            $client = @('run', '--rm', '--name', "$containerName-load", '--network', "container:$containerName",
                '--cpuset-cpus', '16-23', '--memory', '3g', '--mount', $certMount, '--mount', $loadMount,
                '--env', 'SSL_CERT_FILE=/certs/ca.crt', $aspnetImage, 'dotnet', '/load/CacheLoad.dll',
                $system, $repetition, $seconds, $rates)
            Invoke-BenchDocker @client | ForEach-Object {
                if ($_ -like '{*') { [IO.File]::AppendAllText($output, $_ + "`n", $utf8) }
                Write-Output $_
            }
            if ($LASTEXITCODE -ne 0) { throw "Load generation failed for $system repetition $repetition" }
            if (!(Test-Path -LiteralPath $output)) { throw "No measurements written for $system" }
        }
        catch {
            Invoke-BenchDocker logs --tail 35 $containerName
            throw
        }
        finally {
            Invoke-BenchDocker stop --time 2 $containerName | Out-Null
        }
    }
}
